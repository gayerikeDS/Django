from django.conf.urls import url
from MaximusApp import views

app_name='MaximusApp'

urlpatterns = [
    url(r'^signup/$', views.SignUpView.as_view(), name='signup'),
    url(r'^validate_username/$', views.SignUpView.validate_username, name='validate_username'),
]