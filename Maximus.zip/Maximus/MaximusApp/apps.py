from django.apps import AppConfig


class MaximusappConfig(AppConfig):
    name = 'MaximusApp'
