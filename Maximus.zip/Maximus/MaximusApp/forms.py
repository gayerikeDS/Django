from django.forms import ModelForm
from MaximusApp.models import MaximusRegistration

class RegistrationForm(ModelForm):
    class Meta:
        model = MaximusRegistration
        fields = ['userName', 'email', 'password']
    