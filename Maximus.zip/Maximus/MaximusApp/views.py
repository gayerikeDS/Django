from django.contrib.auth.models import User
from django.http import JsonResponse
from django.contrib.auth.forms import UserCreationForm
from django.views.generic.edit import CreateView
from MaximusApp.forms import RegistrationForm
from urllib.parse import parse_qs
from django.views.decorators.csrf import csrf_exempt, requires_csrf_token,csrf_protect
 
class SignUpView(CreateView):
    template_name = 'MaximusApp/signup.html'
    form_class = RegistrationForm
    
    @csrf_exempt
    def validate_username(request):
            form_data = RegistrationForm(request.POST)
            if form_data.is_valid():
                username = form_data.cleaned_data['userName']
                print('abc')
                return JsonResponse(username)
                '''data = {
                        'is_taken': True
                        }
                if data['is_taken']:
                    data['error_message'] = username'''
                    
    
    

    
'''def validate_username(request):
        
        if request.method == 'POST':
            form_data = parse_qs(request.POST['validate_username'].encode('ASCII'))
            username = form_data['userName'][0].decode('utf-8')
            data = {
                    'is_taken': True
                    }
            if data['is_taken']:
                data['error_message'] = username
            return JsonResponse(data)'''
            
       